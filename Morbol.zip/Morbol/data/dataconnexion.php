<?php
session_start();


//Create connexion with Database
$bdd = new PDO('mysql:host=localhost;dbname=morbol', 'root', '');

// Checking of the informations when click on "Connexion"
if(isset($_POST['formconnexion'])) {

    //Convert specials char into HTML entities (htmlspecialchars) 
    //and password encryption (sha1)
    $pseudoconnect = htmlspecialchars($_POST['pseudoconnect']);
    $mdpconnect = sha1($_POST['mdpconnect']);

    //If "pseudo" and "mot de passe" are not empty
    if(!empty($pseudoconnect) AND !empty($mdpconnect)) {
        
        // Launch request to check if the user is already a member
        // Retrieve all from "membre" table Where "pseudo" and "mot de passe" are equal to 
        // what has been entered in the fields.
        $requser = $bdd->prepare("SELECT * FROM membres WHERE pseudo = ? AND mdp = ?");
        $requser->execute(array($pseudoconnect, $mdpconnect));
        $userexist = $requser->rowCount();

        //IF user already exists
        if($userexist == 1) {

            //Open session et redirectory to "Profil" page
            $userinfo = $requser->fetch();
            $_SESSION['id'] = $userinfo['id'];
            $_SESSION['pseudo'] = $userinfo['pseudo'];
            $_SESSION['mail'] = $userinfo['mail'];
            header("location: profil.php?id=".$_SESSION['id']);
        }
        //Else : ERROR -> The informations are not in the Database
        else{
            $erreur = "Le pseudo ou le mot de passe est incorrect !";
        }
    }
    //Else : ERROR -> All the fields have to be completed
    else{
        $erreur = "Tout les champs doivent être rempli !";
    }
}

?>