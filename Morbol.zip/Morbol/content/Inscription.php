<?php include "./data/dataregister.php"; ?>


<div class="container-fluid mx-auto">
    <h2>Inscription</h2>
 
    <form method="POST" action="" class="mx-auto" id="registform">

    <div class="container-fluid form-row">
            <div class="form-group col-md-6"></div>
                <label for="pseudo">Identifiant</label>

                <input class="form-control" type="text" placeholder="Nom du personnage*" id="pseudo" name="pseudo" value="<?php if(isset($pseudo['pseudo'])) { echo $pseudo; } ?>">
            </div>
    </div>
    <br>
    <div class="container-fluid form-row">
            <div class="form-group col-md-6">
                <label for="mail">Email</label>

                <input class="form-control" type="email" placeholder="Votre Email" id="mail" name="mail" value="<?php if(isset($mail['mail'])) { echo $mail; } ?>">
            </div>

            <div class="form-group col-md-6">
                <label for="mail2">Confirmation Email</label>

                <input class="form-control" type="email" placeholder="Confirmez votre mail" id="mail2" name="mail2" value="<?php if(isset($mail2['mail2'])) { echo $mail2; } ?>">
            </div>
    </div>

    <div class="container-fluid form-row">
            <div class="form-group col-md-6">
                <label for="mdp">Mot de passe</label>

                <input class="form-control" type="password" placeholder="Votre mot de passe" id="mdp" name="mdp">
            </div>

            <div class="form-group col-md-6">
                <label for="mdp2">Confirmation MDP</label>

                <input class="form-control" type="password" placeholder="Votre Confirmez MDP" id="mdp2" name="mdp2">
            </div>
            <span class="mx-auto"><input class="text-light btn btn-warning" type="submit" value="S'inscrire" name="forminscription" style="font-size= 1em;"></span>
    </div>

    </form>
        <br>
        <div class="container col-md-3">
            <a id="btnconnect" class="btn btn-success text-light" href="Connexion.php">Se connecter</a>
        </div>
    
    <p class="error"><?php include "data/erreur.php"; ?></p>

</div>