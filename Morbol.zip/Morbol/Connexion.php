<?php include "./data/dataconnexion.php";?>

<!Doctype html>
<html>
<head>
    <title>GDM - Connexion</title>
    <meta charset="utf-8">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="icon" type="image/png" href="img/icon.png">
    <!-- Personal CSS / Bootstrap CSS -->
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Fontawesome -->
    <script src="https://kit.fontawesome.com/03e03ef057.js"></script>

</head>
<body>
    <?php include "content/header.php";?>

    <div class="jumbotron jumbotron-fluid mx-auto">
    <!-- Inclu le formulaire de connexion-->
    <?php include "content/Connect.php";?>

    </div>

    <?php include "content/footer.php";?>
</body>
</html>