<?php
//connexion BDD => Voir singleton & PDO
//(self::$pdo)

//message:

class Message
{
private $id;
private $titre;
private $contenu;

    /**
     * Message constructor.
     * @param string $id
     * @param string $titre
     * @param string $contenu
     */
public function __construct($id = '', $titre = '', $contenu = '')
{
    $this->id = $id;
    $this->titre = $titre;
    $this->contenu = $contenu;
}

//Get the value of id
public function getId()
{
return $this->id;
}

//Set the value of id @return self

public function setId($id)
{
    $this->id = $id;
    return $this;
}

//pareil pour contenu/titre GET -> SET
}