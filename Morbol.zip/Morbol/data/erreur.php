<?php
    //Errors messages will appeare under the form
    if(isset($erreur)){
        echo $erreur;
    }
    ?>