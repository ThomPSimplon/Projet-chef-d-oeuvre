<?php
session_start();


//Création de la connexion à la base de donnée
$bdd = new PDO('mysql:host=localhost;dbname=espace_membre', 'root', '');

if(isset($_GET['id']) AND $_GET['id'] > 0) {


    $getid = intval($_GET['id']);
    $requser = $bdd->prepare("SELECT * FROM membres WHERE id = ?");
    $requser->execute(array($getid));
    $userinfo = $requser->fetch();



?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Accueil de <?= $userinfo['pseudo']; ?></title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href=''>
    <script src=''></script>
</head>
<body>
    <div align="center">
        <h2>Profil</h2>

        <?php
        if(!empty($userinfo['avatar'])) {
        ?>
        <img src="membres/avatars/<?= $userinfo['avatar'];?>" width="150" alt="votre avatar">
        <?php
        }
        ?>
        <br><br>
        <label>Pseudo :</label> <?= $userinfo['pseudo'];?>
        <br>
        <label>Mail :</label> <?= $userinfo['mail'];?>

        <?php

        if(isset($_SESSION['id']) AND $userinfo['id'] == $_SESSION['id']) {
        ?>
            <br>
            <button><a href="editionprofil.php">Editer mon profil</a></button>
            <button><a href="deconnexion.php">Déconnexion</a></button>

        <?php
        }


        ?>
    </div>
</body>
<?php
    //Les messages d'erreurs seront affiché sous le formulaire
    if(isset($erreur)){
        echo $erreur;
    }
    ?>
</html>
<?php
}
?>