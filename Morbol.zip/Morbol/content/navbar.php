<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01" aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarTogglerDemo01">
    <a class="navbar-brand" href="Profil.php?id=1"><i class="fas fa-user-circle"></i> Profil</a>
    <ul class="navbar-nav mr-auto mt-2 mt-lg-0">
      <li class="nav-item active">
        <a class="nav-link" href="#"><i class="fas fa-newspaper"></i> Accueil <span class="sr-only">(current)</span></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fas fa-users"></i> Qui sommes-nous ?</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#"><i class="fas fa-camera-retro"></i> Galerie</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Formular.php"><i class="fas fa-users-cog"></i> Recherche d'équipe</a>
      </li>
    </ul>
  </div>
</nav>