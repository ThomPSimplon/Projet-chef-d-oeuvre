<?php
session_start();


//Création de la connexion à la base de donnée
$bdd = new PDO('mysql:host=localhost;dbname=morbol', 'root', '');

if(isset($_GET['id']) AND $_GET['id'] > 0) {

    $getid = intval($_GET['id']);
    $requser = $bdd->prepare("SELECT * FROM membres WHERE id = ?");
    $requser->execute(array($getid));
    $userinfo = $requser->fetch();
?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Accueil de <?= $userinfo['pseudo']; ?></title>
    <link rel="icon" type="image/png" href="img/icon.png">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Fontawesome -->
    <script src="https://kit.fontawesome.com/03e03ef057.js"></script>
</head>
<body>

    <?php include "content/Header.php"; ?>
    
  <!-- Navbar content -->
    <?php include "content/navbar.php"; ?>

    <div class="jumbotron jumbotron-fluid mx-auto" id="profil">
        <h2>Profil</h2>

        <?php
        if(!empty($userinfo['avatar'])) {
        ?>
        <img class="img-fluid" src="membres/avatars/<?= $userinfo['avatar'];?>" width="150" alt="votre avatar">
        <?php
        }
        ?>
        <br><br>
        <label>Pseudo :</label> <?= $userinfo['pseudo'];?>
        <br>
        <label>Mail :</label> <?= $userinfo['mail'];?>

        <?php

        if(isset($_SESSION['id']) AND $userinfo['id'] == $_SESSION['id']) {
        ?>
            <br>
            <a class="btn btn-success text-light" href="EditProfil.php">Editer mon profil</a>
            <a class="btn btn-danger text-light" href="data/datadeconnexion.php">Déconnexion</a>

        <?php
        }
        ?>
        
    </div>
<?php
}
?>
    <?php include "content/Footer.php"; ?>
</body>
</html>
