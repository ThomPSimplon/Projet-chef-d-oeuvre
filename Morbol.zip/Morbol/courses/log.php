<?php
    require_once 'includes/header.php';
    if(!isset($_SESSION['user'])){
        header("Location: register.php");
    }



   //___________________________________
        //   sur la page connexion
     require_once 'config.config.php';
    session_start();

    $userDAO = new UserDAO();

    //___________________________________

    //config

    define('USER_NAME',  'root');
        define('USER_PASSWORD',  'mdp');
            define('DATABASE_NAME', 'login');
                define('DATABASE_HOTS', 'localhost');

                    spl_autoload_register(function($class){
                        require_once 'classes/'.$class.'.php';
                    });