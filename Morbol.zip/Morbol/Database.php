<?php
//Connexion to Database
    try{
        $bdd = new PDO('mysql:host=localhost;dbname=morbol;charset=utf8', 'root', '');
    } catch(PDOException $e){
        die('Erreur : La connexion à la base de donnée a échouée.'. ' ' .$e->getMessage());
    }
?>