<?php
session_start();

//Create connexion with Database
$bdd = new PDO('mysql:host=localhost;dbname=morbol', 'root', '');

if (empty($_SESSION['id'])) {

    header('location: Registration.php');
    
}
else{


?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <link rel="icon" type="image/png" href="img/icon.png">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <!-- Fontawesome -->
    <script src="https://kit.fontawesome.com/03e03ef057.js"></script>
</head>
<body>
<?php include "content/header.php"; ?>
<?php include "content/navbar.php"; ?>

<div class="container-fluid">
    <div class="jumbotron jumbotron-fluid" id="researching">
        <h2>Ma recherche</h2>
        <form method="POST" action="./content/partyfinding.php">
            <label>Je prévois de jouer :</label>
            <select class="form-control" name="choose">

<!--=================== Retrieve JOBS Name =========================-->
<?php  
        if (isset($_SESSION['id'])){

        $reqform = $bdd->query("SELECT job FROM jobs");

        }

        if($reqform -> rowCount() > 0) {

            while ($jobs = $reqform->fetch() )

        {
?>
<!--================================================================-->

                <option value="<?php echo $jobs['job']; ?>"><?php echo $jobs['job']; ?></option>
            
<?php
        }
    }

?>
            </select>
            <br>
            <label>Je recherche :</label>
            <br>
            <div class="container-fluid col-md-5" id="tank">
                <h6>Tanks</h6>
            <input type="checkbox" name="search[]" value="Paladin" id="PLD"><label for="PLD">Paladin</label>
            <input type="checkbox" name="search[]" value="Guerrier" id="GUE"><label for="GUE">Guerrier</label>
            <input type="checkbox" name="search[]" value="Chevalier Noir" id="CHN"><label for="CHN">Chevalier Noir</label>
            <input type="checkbox" name="search[]" value="Pistosabreur" id="PST"><label for="PST">Pistosabreur</label>
            </div>

            <div class="container-fluid col-md-5" id="heal">
                <h6>Healers</h6>
            <input type="checkbox" name="search[]" value="Mage Blanc" id="MBL"><label for="MBL">Mage Blanc</label>
            <input type="checkbox" name="search[]" value="Erudit" id="ERU"><label for="ERU">Erudit</label>
            <input type="checkbox" name="search[]" value="Astromancien" id="AST"><label for="AST">Astromancien</label>
            </div>

            <div class="container-fluid col-md-5" id="dps1">
                <h6>DPS mêlée</h6>
            <input type="checkbox" name="search[]" value="Moine" id="MOI"><label for="MOI">Moine</label>
            <input type="checkbox" name="search[]" value="Chevalier Dragon" id="DRG"><label for="DRG">Chevalier Dragon</label>
            <input type="checkbox" name="search[]" value="Ninja" id="NIN"><label for="NIN">Ninja</label>
            <input type="checkbox" name="search[]" value="Samourai" id="SAM"><label for="SAM">Samourai</label>
            </div>

            <div class="container-fluid col-md-5" id="dps2">
                <h6>DPS Distance Physique</h6>
            <input type="checkbox" name="search[]" value="Barde" id="BRD"><label for="BRD">Barde</label>
            <input type="checkbox" name="search[]" value="Machiniste" id="MCH"><label for="MCH">Machiniste</label>
            <input type="checkbox" name="search[]" value="Danseur" id="DNS"><label for="DNS">Danseur/se</label>
            </div>

            <div class="container-fluid col-md-5" id="dps3">
                <h6>DPS Distance Magique</h6>
            <input type="checkbox" name="search[]" value="Mage Noir" id="MNO"><label for="MNO">Mage Noir</label>
            <input type="checkbox" name="search[]" value="Invocateur" id="INV"><label for="INV">Invocateur</label>
            <input type="checkbox" name="search[]" value="Mage Rouge" id="MRG"><label for="MRG">Mage Rouge</label>
            <input type="checkbox" name="search[]" value="Mage Bleu" id="MBU"><label for="MBU">Mage Bleu</label>
            </div>

            <div class="container-fluid col-md-5" id="autre">
            <input type="checkbox" name="search[]" value="Autre" id="OTH"><label for="OTH">Autre</label>
            </div>

            <div class="container-fluid col-md-5" id="comment">
            <textarea name="partyfinding" rows="5" cols="43" placeholder="Précisez votre recherche : Instance/Donjon/Raids et autres informations..."></textarea>

            <input type="submit" name="formannonce" value="Envoyer">
            </div>

        </form>
    </div>
</div>


<?php include "content/footer.php"; ?>
</body>
</html>
<?php 
}
?>