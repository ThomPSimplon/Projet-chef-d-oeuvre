<?php
// Connexion with Database
$bdd = new PDO('mysql:host=localhost;dbname=morbol', 'root', '');

if (isset($_POST['formannonce'])) {
    
    $choose = ($_POST['choose']);
    $search = ($_POST['search']);
    $comment = ($_POST['partyfinding']);

    // if (!empty($_POST['choose']) AND !empty($_POST['search']) AND !empty($_POST['comment'])) {
        
    //     $reqannonce = $bdd->prepare();
    // }
}



var_dump($_POST);




?>