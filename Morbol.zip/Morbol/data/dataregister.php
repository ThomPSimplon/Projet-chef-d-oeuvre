<?php

// Connexion with Database
$bdd = new PDO('mysql:host=localhost;dbname=morbol', 'root', '');


// Checking of the informations when click on "S'inscrir"
if(isset($_POST['forminscription'])) {

    //Convert specials char into HTML entities (htmlspecialchars) 
    //and password encryption (sha1)
    $pseudo = htmlspecialchars($_POST['pseudo']);
    $mail = htmlspecialchars($_POST['mail']);
    $mail2 = htmlspecialchars($_POST['mail2']);
    $mdp = sha1($_POST['mdp']);
    $mdp2 = sha1($_POST['mdp2']);

    // IF the informations are not empty
    if (!empty($_POST['pseudo']) AND !empty($_POST['mail']) AND !empty($_POST['mail2']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])) {
        
        // Check the characters' number in "pseudo
        $pseudolength = strlen($pseudo);
        if($pseudolength <= 255){

            // Request to check if "pseudo" is not already use by someone else (no double)
            // Retrieve all from "membres" table Where "pseudo" equal to 
            // what has been entered in the field.
            $reqpseudo = $bdd->prepare("SELECT * FROM membres WHERE pseudo = ?");
            $reqpseudo->execute(array($pseudo));
            $pseudoexist = $reqpseudo->rowCount();

            //IF pseudo already exists
            if($pseudoexist == 0) {

                // We use filter to check if the email is validate
                if(filter_var($mail, FILTER_VALIDATE_EMAIL)) {

                    //IF mail and check mail are equals
                    if($mail == $mail2){

                        // Request to check the mail is not already use
                        // Retrieve all from "membres" table where mail is equal to what has been entered in the field
                        $reqmail = $bdd->prepare("SELECT * FROM membres WHERE mail = ?");
                        $reqmail->execute(array($mail));
                        $mailexist = $reqmail->rowCount();

                        //IF mail doesn't exist
                        if($mailexist == 0) {

                            //IF password and check password are equals
                            if($mdp == $mdp2){

                                // Request to add user in Database with all informations completed
                                $insertmbr = $bdd->prepare("INSERT INTO membres(pseudo, mail, mdp) VALUES(?, ?, ?)");
                                $insertmbr->execute(array($pseudo, $mail, $mdp));
                                $erreur = 'Votre compte a bien été créé ! <br> <button type="button" class="btn btn-success"><a class="text-light" href="connexion.php">Se connecter</a></button>';
                                // Account is create !
                                
                            }
                            


                            //ELSE : Error -> Passwords are not the same
                            else{
                                $erreur = "Les deux mots de passes ne correspondent pas !";
                            }
                        }
                        //ELSE : Error -> Email already use
                        else{
                            $erreur = "Adresse mail déjà utilisée !";
                        }
                    }
                    //ELSE : Error -> Emails are not the same
                    else{
                        $erreur = "Les deux adresses mails ne correspondent pas !";
                    }


                }
                //ELSE : Error -> Email is not correct
                else{
                    $erreur = "Votre adresse mail n'est pas valide !";
                }

            }
            //ELSE : Error -> "Pseudo" already use
            else{
            $erreur = "Pseudo déjà utilisé !";
            }
        
        }
        //ELSE : Error -> "Pseudo" is too long
        else{
            $erreur = "Votre pseudo ne doit pas dépasser 255 caractères !";
        }

    }
    //ELSE : Error -> All fields are not complete
    else{
        $erreur = "Tous les champs doivent être complêté !";
    }
}

?>