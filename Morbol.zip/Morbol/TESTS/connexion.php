<?php
session_start();


//Création de la connexion à la base de donnée
$bdd = new PDO('mysql:host=localhost;dbname=espace_membre', 'root', '');

//Lancement de la vérification sur les champs du formulaire au clique du bouton "Se connecter"
if(isset($_POST['formconnexion'])) {

    //Convertion des caractères spéciaux en entités HTML (htmlspecialchars) 
    //et cryptage des mots de passes (sha1)
    $pseudoconnect = htmlspecialchars($_POST['pseudoconnect']);
    $mdpconnect = sha1($_POST['mdpconnect']);

    //Si les champs "pseudo" et "mot de passe" ne sont pas vide
    if(!empty($pseudoconnect) AND !empty($mdpconnect)) {
        
        //On lance une requête pour vérifier que l'utilisateur soit bien enregistrer
        //On récupère TOUT de la table "membre" où le pseudo et le mot de passe sont égaux à ce qui a été
        //entré dans les champs du formulaire de connexion
        $requser = $bdd->prepare("SELECT * FROM membres WHERE pseudo = ? AND motdepasse = ?");
        $requser->execute(array($pseudoconnect, $mdpconnect));
        $userexist = $requser->rowCount();

        //Si l'utilisateur existe dans la base de données
        if($userexist == 1) {

            //On lance la session et redirige l'utilisateur sur sa page "Profil"
            $userinfo = $requser->fetch();
            $_SESSION['id'] = $userinfo['id'];
            $_SESSION['pseudo'] = $userinfo['pseudo'];
            $_SESSION['mail'] = $userinfo['mail'];
            header("location: profil.php?id=".$_SESSION['id']);
        }
        //Sinon : ERREUR -> Les informations renseignés ne sont pas dans la base de données
        else{
            $erreur = "Le pseudo ou le mot de passe est incorrect !";
        }
    }
    //Sinon : ERREUR -> Tout les champs n'ont pas été rempli
    else{
        $erreur = "Tout les champs doivent être rempli !";
    }
}

?>

<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Connexion</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href=''>
    <script src=''></script>
</head>
<body>
    <div align=center>
        <h2>Connexion</h2>

        <form method="POST" action="">
            <table>
                <tr>
                    <td>
                        <label for="pseudo">Pseudo :</label>
                    </td>

                    <td>
                        <input type="text" placeholder="Votre Pseudo" id="pseudo" name="pseudoconnect" value="">
                    </td>
                </tr>

                <tr>
                    <td>
                        <label for="mdp">Mot de passe :</label>
                    </td>

                    <td>
                        <input type="password" placeholder="Votre mot de passe" id="mdp" name="mdpconnect" value="">
                    </td>
                </tr>
            </table>

            <input type="submit" value="Se connecter" name="formconnexion">

        </form>
        <button><a href="inscription.php">S'incrire</a></button>
    <?php
    //Les messages d'erreurs seront affiché sous le formulaire
    if(isset($erreur)){
        echo $erreur;
    }
    ?>
    </div>
</body>
</html>