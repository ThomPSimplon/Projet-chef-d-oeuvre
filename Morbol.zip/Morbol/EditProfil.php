<?php
session_start();


//Connexion with Database
$bdd = new PDO('mysql:host=localhost;dbname=morbol', 'root', '');

// If session is open with the ID
if(isset($_SESSION['id'])) {

    //Request to retrieve all informations from the user with the fetch
    $requser = $bdd->prepare("SELECT * FROM membres WHERE id = ?");
    $requser->execute(array($_SESSION['id']));
    $user = $requser->fetch();

    // Condition to change "pseudo"
    if(isset($_POST['newpseudo']) AND !empty($_POST['newpseudo']) AND $_POST['newpseudo'] != $user['pseudo']){

        $newpseudo = htmlspecialchars($_POST['newpseudo']) ;
        $insertpseudo = $bdd->prepare("UPDATE membres SET pseudo = ? WHERE id = ?");
        $insertpseudo->execute(array($newpseudo, $_SESSION['id']));
        header('location: Profil.php?id='.$_SESSION['id']);

    }

    // Condition to change Email
    if(isset($_POST['newmail']) AND !empty($_POST['newmail']) AND $_POST['newmail'] != $user['mail']){

        
        $newmail = htmlspecialchars($_POST['newmail']) ;

        $insertmail = $bdd->prepare("UPDATE membres SET mail = ? WHERE id = ?");
        $insertmail->execute(array($newmail, $_SESSION['id']));
        $newmailexist = $insertmail->rowCount();
        header('location: Profil.php?id='.$_SESSION['id']);
    }

    // Condition to change Password
    if(isset($_POST['newmdp1']) AND !empty($_POST['newmdp1']) AND isset($_POST['newmdp2']) AND !empty($_POST['newmdp2'])){

        $mdp1 = sha1($_POST['newmdp1']);
        $mdp2 = sha1($_POST['newmdp2']);

        if($mdp1 == $mdp2) {

            $insertmdp = $bdd->prepare("UPDATE membres SET mdp = ? WHERE id = ?");
            $insertmdp->execute(array($mdp1, $_SESSION['id']));
            header('location: Profil.php?id='.$_SESSION['id']);

        }
        else {

            $msg = "Vos deux mots de passes ne sont pas identique !";
        }

    }

    // Option 'avatar' (Profil picture)
    if(isset($_FILES['avatar']) AND !empty($_FILES['avatar']['name'])){

        $tailleMax = 2097152;
        $extensionsValides = array('jpg', 'jpeg', 'gif', 'png');

        if($_FILES['avatar']['size'] <= $tailleMax) {

            $extensionUpload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.'), 1));
            
            if(in_array($extensionUpload, $extensionsValides)){

                $chemin = "membres/avatars/".$_SESSION['id'].".". $extensionUpload;
                $resultat = move_uploaded_file($_FILES['avatar']['tmp_name'], $chemin);
                
                if($resultat) {

                    $updateavatar = $bdd->prepare('UPDATE membres SET avatar = :avatar WHERE id = :id');
                    $updateavatar->execute(array(
                        'avatar' => $_SESSION['id'].".".$extensionUpload,
                        'id' => $_SESSION['id']
                    ));
                    header('location: profil.php?id='.$_SESSION['id']);

                }
                else {
                    $msg = "Une erreur est survenue lors de l'importation de l'avatar.";
                }

            }
            else {
                $msg = "Votre avatar doit être au format (.jpg / .jpeg / .gif / .png) !";
            }

        }
        else {
            $msg = "Votre avatar ne doit pas dépasser 2Mo !";
        }

    }

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Edit Profil <?= $user['pseudo']; ?></title>
    <link rel="icon" type="image/png" href="img/icon.png">
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href='style.css'>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
    <script src=''></script>
</head>
<body>

    <?php include "content/Header.php"; ?>

    <?php include "content/navbar.php"; ?>
    
    <div class="jumbotron jumbotron-fluid mx-auto">
        <h2>Edition du profil</h2>

        <form method="POST" action="" enctype="multipart/form-data">
        <div class="container-fluid mx-auto needcenter">
        <?php
        if(!empty($userinfo['avatar'])) {
        ?>
        <img class="img-fluid" src="membres/avatars/<?php $user['avatar'];?>" width="150" alt="votre avatar">
        <?php
        }
        ?>
        
        
        <label>Avatar :</label>
        <input type="file" name="avatar">

        </div>

        <table class="mt-1 mx-auto">
            <tr>
                <td>
                    <label>Modifier Pseudo</label>
                </td>

                <td>
                <input type="text" name="newpseudo" placeholder="Modifier Pseudo" value="<?php echo $user['pseudo']; ?>">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Modifier Mail</label>
                </td>

                <td>
                <input type="email" name="newmail" placeholder="Modifier Mail" value="<?php echo $user['mail']; ?>">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Modifier MDP</label>
                </td>

                <td>
                <input type="password" name="newmdp1" placeholder="Modifier Mot de passe">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Confirmer MDP</label>
                </td>

                <td>
                <input type="password" name="newmdp2" placeholder="Confirmer nouveau MDP">
                </td>
            </tr>
        
        </table>

        <div class="container-fluid mx-auto needcenter">
            <a class="btn btn-success" href="javascript:history.go(-1)">Retour</a>
            <input class="btn btn-warning" type="submit" value="Modifier">
        </div>
        </form>
<?php
    //Les messages d'erreurs seront affiché sous le formulaire
    if(isset($msg)){
        echo $msg;
    }
?>


    </div>

    <?php include "content/Footer.php"; ?>
</body>

</html>
<?php
}
else {
    header("location: connexion.php");
}
?>