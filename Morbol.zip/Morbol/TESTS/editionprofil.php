<?php
session_start();


//Création de la connexion à la base de donnée
$bdd = new PDO('mysql:host=localhost;dbname=espace_membre', 'root', '');

if(isset($_SESSION['id'])) {

    $requser = $bdd->prepare("SELECT * FROM membres WHERE id = ?");
    $requser->execute(array($_SESSION['id']));
    $user = $requser->fetch();

    if(isset($_POST['newpseudo']) AND !empty($_POST['newpseudo']) AND $_POST['newpseudo'] != $user['pseudo']){

        $newpseudo = htmlspecialchars($_POST['newpseudo']) ;
        $insertpseudo = $bdd->prepare("UPDATE membres SET pseudo = ? WHERE id = ?");
        $insertpseudo->execute(array($newpseudo, $_SESSION['id']));
        header('location: profil.php?id='.$_SESSION['id']);

    }


    if(isset($_POST['newmail']) AND !empty($_POST['newmail']) AND $_POST['newmail'] != $user['mail']){

        
        $newmail = htmlspecialchars($_POST['newmail']) ;

        $insertmail = $bdd->prepare("UPDATE membres SET mail = ? WHERE id = ?");
        $insertmail->execute(array($newmail, $_SESSION['id']));
        $newmailexist = $insertmail->rowCount();
        header('location: profil.php?id='.$_SESSION['id']);
    }


    if(isset($_POST['newmdp1']) AND !empty($_POST['newmdp1']) AND isset($_POST['newmdp2']) AND !empty($_POST['newmdp2'])){

        $mdp1 = sha1($_POST['newmdp1']);
        $mdp2 = sha1($_POST['newmdp2']);

        if($mdp1 == $mdp2) {

            $insertmdp = $bdd->prepare("UPDATE membres SET motdepasse = ? WHERE id = ?");
            $insertmdp->execute(array($mdp1, $_SESSION['id']));
            header('location: profil.php?id='.$_SESSION['id']);

        }
        else {

            $msg = "Vos deux mots de passes ne sont pas identique !";
        }

    }


    if(isset($_FILES['avatar']) AND !empty($_FILES['avatar']['name'])){

        $tailleMax = 2097152;
        $extensionsValides = array('jpg', 'jpeg', 'gif', 'png');

        if($_FILES['avatar']['size'] <= $tailleMax) {

            $extensionUpload = strtolower(substr(strrchr($_FILES['avatar']['name'], '.'), 1));
            
            if(in_array($extensionUpload, $extensionsValides)){

                $chemin = "membres/avatars/".$_SESSION['id'].".". $extensionUpload;
                $resultat = move_uploaded_file($_FILES['avatar']['tmp_name'], $chemin);
                
                if($resultat) {

                    $updateavatar = $bdd->prepare('UPDATE membres SET avatar = :avatar WHERE id = :id');
                    $updateavatar->execute(array(
                        'avatar' => $_SESSION['id'].".".$extensionUpload,
                        'id' => $_SESSION['id']
                    ));
                    header('location: profil.php?id='.$_SESSION['id']);

                }
                else {
                    $msg = "Une erreur est survenue lors de l'importation de l'avatar.";
                }

            }
            else {
                $msg = "Votre avatar doit être au format (.jpg / .jpeg / .gif / .png) !";
            }

        }
        else {
            $msg = "Votre avatar ne doit pas dépasser 2Mo !";
        }

    }

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Accueil de <?= $userinfo['pseudo']; ?></title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href=''>
    <script src=''></script>
</head>
<body>
    <div align="center">
        <h2>Edition du profil</h2>
        <form method="POST" action="" enctype="multipart/form-data">

        <?php
        if(!empty($userinfo['avatar'])) {
        ?>
        <img src="membres/avatars/<?= $userinfo['avatar'];?>" width="150" alt="votre avatar">
        <?php
        }
        ?>
        <br><br>

        <label>Avatar :</label>
        <input type="file" name="avatar">

        <table>
            <tr>
                <td>
                    <label>Modifier Pseudo</label>
                </td>

                <td>
                <input type="text" name="newpseudo" placeholder="Modifier Pseudo" value="<?php echo $user['pseudo']; ?>">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Modifier Mail</label>
                </td>

                <td>
                <input type="email" name="newmail" placeholder="Modifier Mail" value="<?php echo $user['mail']; ?>">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Modifier MDP</label>
                </td>

                <td>
                <input type="password" name="newmdp1" placeholder="Modifier Mot de passe">
                </td>
            </tr>

            <tr>
                <td>
                    <label>Confirmer MDP</label>
                </td>

                <td>
                <input type="password" name="newmdp2" placeholder="Confirmer nouveau MDP">
                </td>
            </tr>
        
        </table>
        <button><a href="javascript:history.go(-1)">Retour</a></button>
        <input type="submit" value="Modifier">
        </form>
<?php
    //Les messages d'erreurs seront affiché sous le formulaire
    if(isset($msg)){
        echo $msg;
    }
?>


    </div>
</body>

</html>
<?php
}
else {
    header("location: connexion.php");
}
?>