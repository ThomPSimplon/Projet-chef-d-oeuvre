<?php

//Création de la connexion à la base de donnée
$bdd = new PDO('mysql:host=localhost;dbname=espace_membre', 'root', '');


//Lancement de la vérification sur les champs du formulaire au clique du bouton "s'inscrir"
if(isset($_POST['forminscription'])) {

    //Convertion des caractères spéciaux en entités HTML (htmlspecialchars) 
    //et cryptage des mots de passes (sha1)
    $pseudo = htmlspecialchars($_POST['pseudo']);
    $mail = htmlspecialchars($_POST['mail']);
    $mail2 = htmlspecialchars($_POST['mail2']);
    $mdp = sha1($_POST['mdp']);
    $mdp2 = sha1($_POST['mdp2']);

    //Si les informations ne sont pas vide
    if (!empty($_POST['pseudo']) AND !empty($_POST['mail']) AND !empty($_POST['mail2']) AND !empty($_POST['mdp']) AND !empty($_POST['mdp2'])) {
        
        //Vérification du nombre de caractères entrés dans la case "pseudo"
        $pseudolength = strlen($pseudo);
        if($pseudolength <= 255){

            //Requête pour vérifier que le pseudo n'est pas déjà utilisé (pour éviter les doublons)
            //On récupère TOUT (*) de la table membres où le pseudo est égal à celui renseigné dans le formulaire
            $reqpseudo = $bdd->prepare("SELECT * FROM membres WHERE pseudo = ?");
            $reqpseudo->execute(array($pseudo));
            $pseudoexist = $reqpseudo->rowCount();

            //Si le pseudo n'existe pas, on continue
            if($pseudoexist == 0) {

                //On utilise un filtre pour vérifier que l'entrée soit bien une adresse mail
                if(filter_var($mail, FILTER_VALIDATE_EMAIL)) {

                    //Si l'adresse mail entrée correspond à celle de la confirmation
                    if($mail == $mail2){

                        //Requête pour vérifier que l'adresse mail n'a pas déjà été utilisée
                        //On récupère TOUT (*) de la table membres où l'adresse mail est égale à celle renseignée
                        //dans le formulaire
                        $reqmail = $bdd->prepare("SELECT * FROM membres WHERE mail = ?");
                        $reqmail->execute(array($mail));
                        $mailexist = $reqmail->rowCount();

                        //Si le mail n'existe pas, on continue
                        if($mailexist == 0) {

                            //Si le mot de passe entré correspond à celui de la confirmation
                            if($mdp == $mdp2){

                                //Requête pour insérer les informations du formulaire d'inscription dans la base de donnée
                                $insertmbr = $bdd->prepare("INSERT INTO membres(pseudo, mail, motdepasse) VALUES(?, ?, ?)");
                                $insertmbr->execute(array($pseudo, $mail, $mdp));
                                $erreur = "Votre compte a bien été créé ! <button><a href=\"connexion.php\">Se connecter</a></button>";
                                //Le compte a bien été créé

                            }

                            //Sinon : Erreur -> Les mots de passes ne correspondent pas
                            else{
                                $erreur = "Les deux mots de passes ne correspondent pas !";
                            }
                        }
                        //Sinon : Erreur -> L'adresse mail est déjà utilisée
                        else{
                            $erreur = "Adresse mail déjà utilisée !";
                        }
                    }
                    //Sinon : Erreur -> Les adresses mails ne sont pas les mêmes
                    else{
                        $erreur = "Les deux adresses mails ne correspondent pas !";
                    }


                }
                //Sinon : Erreur -> L'adresse mail n'est pas validé
                else{
                    $erreur = "Votre adresse mail n'est pas valide !";
                }

            }
            //Sinon : Erreur -> Le pseudo est déjà utilisé
            else{
            $erreur = "Pseudo déjà utilisé !";
            }
        
        }
        //Sinon : Erreur -> Le pseudo dépasse les 255 caractères
        else{
            $erreur = "Votre pseudo ne doit pas dépasser 255 caractères !";
        }

    }
    //Sinon : Erreur -> Tout les champs n'ont pas été rempli
    else{
        $erreur = "Tous les champs doivent être complêté !";
    }
}

?>


<!DOCTYPE html>
<html>
<head>
    <meta charset='utf-8'>
    <meta http-equiv='X-UA-Compatible' content='IE=edge'>
    <title>Page Title</title>
    <meta name='viewport' content='width=device-width, initial-scale=1'>
    <link rel='stylesheet' type='text/css' media='screen' href=''>
    <script src=''></script>
</head>
<body>
    <div align="center">
    <h2>Inscription</h2>
 
    <form method="POST" action="">
<!-- Tableau contenant les champs du formulaire d'inscription -->
    <table>

        <tr>
            <td>
                <label for="pseudo">Identifiant</label>
            </td>

            <td>
                <input type="text" placeholder="Votre pseudo" id="pseudo" name="pseudo" value="<?php if(isset($pseudo['pseudo'])) { echo $pseudo; } ?>">
            </td>
        </tr>

        <tr>
            <td>
                <label for="mail">Email</label>
            </td>

            <td>
                <input type="email" placeholder="Votre Email" id="mail" name="mail" value="<?php if(isset($mail['mail'])) { echo $mail; } ?>">
            </td>
        </tr>

        <tr>
            <td>
                <label for="mail2">Confirmation Email</label>
            </td>

            <td>
                <input type="email" placeholder="Confirmez votre mail" id="mail2" name="mail2" value="<?php if(isset($mail2['mail2'])) { echo $mail2; } ?>">
            </td>
        </tr>

        <tr>
            <td>
                <label for="mdp">Mot de passe</label>
            </td>

            <td>
                <input type="password" placeholder="Votre mot de passe" id="mdp" name="mdp">
            </td>
        </tr>

        <tr>
            <td>
                <label for="mdp2">Confirmation MDP</label>
            </td>

            <td>
                <input type="password" placeholder="Votre Confirmez MDP" id="mdp2" name="mdp2">
            </td>
        </tr>

    </table>

    <input type="submit" value="S'inscrir" name="forminscription">

    </form>

    <?php
    //Les messages d'erreurs seront affiché sous le formulaire
    if(isset($erreur)){
        echo $erreur;
    }
    ?>

    </div>
</body>
</html>