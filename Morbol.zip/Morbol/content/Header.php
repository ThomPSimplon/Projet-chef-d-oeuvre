<header>
    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-3 text-center">
                <img class="img-fluid" src="img/LOGO.png" alt="">
            </div>
            <div class="col-lg-9">
                <h1 id="mainTitle" class="text-white text-center mt-lg-5 pt-lg-5">La Gueule Du Morbol</h1>
            </div>
        </div>
    </div>
</header>