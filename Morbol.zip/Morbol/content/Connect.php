
<div class="container-fluid mx-auto">
    <h2>Connexion</h2>

        <form method="POST" action="" class="mx-auto" id="connecting">
            
        <div class="form-row">

            <div class="form-group col-md-6">
                <label for="pseudo">Pseudo :</label>
                <input type="text" placeholder="Votre Pseudo" id="pseudo" name="pseudoconnect" value="" class="form-control">
            </div>

                <div class="form-group col-md-6">
                    <label for="mdp">Mot de passe :</label>
                    <input type="password" placeholder="Votre mot de passe" id="mdp" name="mdpconnect" value="" class="form-control">
                </div>

            <span class="mx-auto"><input class="text-light btn btn-success" type="submit" value="Se connecter" name="formconnexion" style="font-size: 1em;"></span>

        </div>

        </form>
        

        <div class="container col-md-3">
            <a id="btninscrip" class="text-light btn btn-warning" href="./Registration.php">S'incrire</a>
        </div>
    
    
        <p class="error"><?php include "data/erreur.php";?></p>
</div>